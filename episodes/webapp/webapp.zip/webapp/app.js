// Define API endpoint and DOM elements
const googleSheet = '';


// Get Data


// Filter Data


// Display Data